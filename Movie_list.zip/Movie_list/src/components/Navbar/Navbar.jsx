import React from "react";
import "./Navbar.css";
import Fire from "../../assets/fire.png";
import Star from "../../assets/star.png";
import Party from "../../assets/party-face.png";

const Navbar = ({ category, setCategory }) => {
  return (
    <nav className="navbar">
      <h1 className="navbar_title">Movie List</h1>

      <div className="navbar_links">
        <button
          className={category === "popular" ? "active_link" : ""}
          onClick={() => setCategory("popular")}
        >
          Popular <img src={Fire} alt="fire emoji" className="navbar_emoji" />
        </button>

        <button
          className={category === "top_rated" ? "active_link" : ""}
          onClick={() => setCategory("top_rated")}
        >
          Top Rated <img src={Party} alt="party emoji" className="navbar_emoji" />
        </button>

        <button
          className={category === "upcoming" ? "active_link" : ""}
          onClick={() => setCategory("upcoming")}
        >
          Upcoming <img src={Star} alt="star emoji" className="navbar_emoji" />
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
