import React, { useState, useEffect } from 'react';
import './Movielist.css';
import MovieCard from './MovieCard';
import Fire from "../../../assets/fire.png";
import FilterGroup from './FilterGroup';

const Movielist = () => {
  const [allMovies, setAllMovies] = useState([]);
  const [movies, setMovies] = useState([]);
  const [minRating, setMinRating] = useState(0);
  const [sort, setSort] = useState({ by: "popularity", order: "asc" });
  const [category, setCategory] = useState("popular"); // popular, upcoming, top_rated
  const [isLoading, setIsLoading] = useState(true);

  // Fetch movies whenever category changes
  useEffect(() => {
    fetchMovies(category);
  }, [category]);

  const fetchMovies = async (cat) => {
    setIsLoading(true);
    try {
      const response = await fetch(
        `https://api.themoviedb.org/3/movie/${cat}?api_key=06c69775a89af33a1c3290df895cc6e4`
      );
      const data = await response.json();
      setAllMovies(data.results || []);
      setMovies(data.results || []);
      setIsLoading(false);
    } catch (error) {
      console.error("Failed to fetch movies:", error);
      setIsLoading(false);
    }
  };

  const handleFilter = (rate) => {
    setMinRating(rate);
    // TMDB rating is out of 10, buttons are 1-5
    const filtered = allMovies.filter(movie => movie.vote_average >= rate * 2);
    setMovies(filtered);
  };

  const handleSort = (e) => {
    const { name, value } = e.target;
    const newSort = { ...sort, [name]: value };
    setSort(newSort);

    const sorted = [...movies].sort((a, b) => {
      let result = 0;
      switch (newSort.by) {
        case "rating":
          result = a.vote_average - b.vote_average;
          break;
        case "release_date":
          result = new Date(a.release_date) - new Date(b.release_date);
          break;
        case "title":
          result = a.title.localeCompare(b.title);
          break;
        default:
          result = a.popularity - b.popularity;
      }
      return newSort.order === "asc" ? result : -result;
    });

    setMovies(sorted);
  };

  return (
    <section className="movie_list">
      <header className="align_center movie_list_header">
        <h2 className="align_center movie_list_heading">
          Movies
          <img src={Fire} alt="fire emoji" className="navbar_emoji" />
        </h2>

        <div className="align_center movie_list_fs">
          <FilterGroup
            minRating={minRating}
            onRatingClick={handleFilter}
            ratings={[5, 4, 3]}
          />

          <select name="by" onChange={handleSort} value={sort.by} className="movie_sorting">
            <option value="popularity">Sort by popularity</option>
            <option value="rating">Sort by rating</option>
            <option value="release_date">Sort by release date</option>
            <option value="title">Sort by title</option>
          </select>

          <select name="order" onChange={handleSort} value={sort.order} className="movie_sorting">
            <option value="asc">Ascending</option>
            <option value="desc">Descending</option>
          </select>
        </div>
      </header>

      <div className="movie_cards">
        {isLoading ? (
          <p className="loading_text">Loading movies...</p>
        ) : movies.length > 0 ? (
          movies.map((movie) => <MovieCard key={movie.id} movie={movie} />)
        ) : (
          <p className="loading_text">No movies found for this rating.</p>
        )}
      </div>
    </section>
  );
};

export default Movielist;
