import React from 'react'

const FilterGroup = ({ minRating, onRatingClick, ratings }) => {
  return (
    <ul className="align_center movie_list_fs_links">
      {ratings.map(rate => (
        <li
          key={rate}
          className={minRating === rate ? 'movie_filter_item active' : 'movie_filter_item'}
          onClick={() => onRatingClick(rate)}
        >
          {rate}+ Star
        </li>
      ))}
    </ul>
  )
}

export default FilterGroup
