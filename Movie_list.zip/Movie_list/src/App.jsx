import react from 'react'

import './App.css'
import Navbar from './components/Navbar/Navbar';
import Movielist from './components/Navbar/MovieList/Movielist';

const App = () => {
  return (
    <div className='App'>
      <Navbar/>
      
      <Movielist/>
    </div>
  );
};

export default App;